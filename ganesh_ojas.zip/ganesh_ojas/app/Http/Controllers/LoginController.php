<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\LoginController;
use App\Models\Register;
use App\Models\File;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use DB;
use Illuminate\Support\Facades\Session;


class LoginController extends Controller
{
    function login(Request $req)
    {      
      $email= $req->input('email');
      $password=$req->input('password');
      $user=Register::where('email',$email)->first();   
      if($user['userrole']=='user') 
      {    
      $req->session()->put('user',$user);
       return view('userpage') ;    
      }  
      else if($user['userrole']=='admin') 
      {
        $req->session()->put('user',$user);
        $user=Register::all();  
        return view('admin.adminpage',['user'=>$user]) ;   
      }
  
     else
     {      
       
       return redirect('/')->with('loginstatus','Please check Email or Password');   
     
     }

   
    }
    function submit_reg(Request $req)
    {
      $req->validate([

        'name' => 'required|max:255',
        'email' => 'required|unique:registers,email|max:255'
      ]);
     
     
           $fileModel = new Register;
           $fileModel->name = $req->input('name');
           $fileModel->userrole = $req->input('userrole');
           $fileModel->email = $req->input('email');
           $fileModel->password =Hash::make($req->input('password'));           
            $fileModel->save();
            return back()
            ->with('success','Registered Successfully.');         
           
    }
    function logout(Request $req)
    {
        $req->session()->forget('user');  
        return redirect('/')->with('loginstatus','Logout Successfully.');
    }
    function homepage()
    {
                $data=File::all();
                return view('admin.adminhoke',['result'=>$data]);

    }
    public function edituser(Request $req)
    {
      $id= $req->id;

    return  $user=Register::where('id',$id)->first(); 
 
    
    }
    public function deleteuser(Request $req)
    {
      $id= $req->id;
     $delete=Register::where('id', $id)->delete();
     if($delete)
     {

   
     return  back()->with('delete','Deleted Successfully');  
    }  
    else
    {
      return  back()->with('delete','Not Deleted ');
    }
 
    
    }
    public function updateuser(Request $req)
    {
      $id= $req->input('getid');
      $name= $req->input('name');
      $email= $req->input('email');
      $userrole= $req->input('userrole');     
       Register::where('id', $id)->update(['name' => $name,'email'=>$email,'userrole'=>$userrole]);
       return  back()->with('update','Updated Successfully');    
    }

  
    
}

