
<?php $__env->startSection('content'); ?>
<?php if($message = Session::get('fileuploaded')): ?>
            <div class="alert alert-success">
                <strong><?php echo e($message); ?></strong>
            </div>
          <?php endif; ?>

          <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>

          <form class="navbar-form" action="/search" method="post">
          <?php echo csrf_field(); ?>
        <div  class="form-group">
          <input  type="text" name="search" class="form-control" placeholder="Filename/uploadedby/type/size">
        </div>
        <button type="submit" class="btn btn-default">Filter</button>
      </form>


<div class="col-sm-6 col-sm-offset-6" >
<form action="/uploadimage" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<input type="file" name="file">
<br/>
<button type="submit" name="upload">UploadImage</button>
</form>
</div>


<div class="container">
  <h2>User Data</h2>
         
  <table class="table table-hover">
    <thead>
      <tr>
      <th>Image</th>
        <th>Uploaded By</th>
        <th>File Type</th>
        <th>File Size</th>
        <th>File Name</th>
        
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
       
        <?php if( $value->file_extension=='jpg' or $value->file_extension=='png' ): ?>
        <td><img src="/uploads/<?php echo e($value->newfilename); ?>" width="75px" height="45px"></td>
        <?php else: ?>
        <td>Preview NA</td>
        <?php endif; ?>
      
        <td> <?php echo e($value->file_uploadby); ?></td>
        <td> <?php echo e($value->file_type); ?></td>
        <td> <?php echo e($value->file_size); ?></td>
        <td> <?php echo e($value->file_name); ?></td>
        
      
   
    </tr>   
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
    
     
    </tbody>
  </table>
</div>

</body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ganesh_dckap\resources\views/homepage.blade.php ENDPATH**/ ?>