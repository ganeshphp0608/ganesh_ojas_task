<!-- 
<div class="panel-footer">Panel footer</div> -->
<div class="footer">
  <p>Copy right &copy; Ojas </p>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\ganesh_ojas\resources\views/footer.blade.php ENDPATH**/ ?>