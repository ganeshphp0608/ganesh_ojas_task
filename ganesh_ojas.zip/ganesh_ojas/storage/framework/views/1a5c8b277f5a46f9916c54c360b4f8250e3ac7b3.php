<footer class="footer">
        <div class=" container-fluid ">
          <nav>
           
          </nav>
          <div class="copyright" id="copyright">
            &copy;      
            Designed by <a href="#" target="_blank">DCKAP</a>
          </div>
        </div>
      </footer><?php /**PATH C:\xampp\htdocs\laravel\ganesh_dckap\resources\views/admin-footer.blade.php ENDPATH**/ ?>