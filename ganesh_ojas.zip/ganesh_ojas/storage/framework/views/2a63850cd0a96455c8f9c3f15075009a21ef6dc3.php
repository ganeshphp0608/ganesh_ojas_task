<!-- 
<div class="panel-footer">Panel footer</div> -->
<div class="footer">
  <p>&copy; Dckap </p>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\ganesh_dckap\resources\views/footer.blade.php ENDPATH**/ ?>