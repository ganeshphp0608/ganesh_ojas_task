
<?php $__env->startSection('content'); ?>
<h1>Admin page</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('views.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ganesh_ojas\resources\views//admin/adminpage.blade.php ENDPATH**/ ?>