
<?php $__env->startSection('content'); ?>
<div class="container">
<form method="post" action="submit_reg" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <strong><?php echo e($message); ?></strong>
            </div>
          <?php endif; ?>

          <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
  <fieldset>
    <legend>Registration Form </legend>
    
    <div class="form-group">
      <label for="Name">Name</label>
      <input type="text" class="form-control" name="name" id="name"  placeholder="Enter Name"  required>
      
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>            
    </div>
   
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input type="password" name="password" class="form-control"  id="txtNewPassword" placeholder="Password">

    </div>
     <div class="form-group">
      <label for="exampleInputPassword1">Confirm Password</label>
      <input type="password"  class="form-control"   id="txtConfirmPassword" placeholder="Confirm Password" required>
      <div id="match"></div>
    </div>
   
     <button type="submit" class="btn btn-primary">Submit</button>    
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\ganesh_dckap\resources\views/register.blade.php ENDPATH**/ ?>