@extends('layout')
@section('content')
<h1>your in user page</h1> 
@endsection
