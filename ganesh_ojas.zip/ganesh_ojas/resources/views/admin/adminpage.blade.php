@extends('layout')
@section('content')
<h1>Admin page</h1>
<div class="container">
@if ($message = Session::get('delete'))
            <div class="alert alert-success">
                <strong>{{ $message }}</strong>
            </div>
          @endif
          @if ($message = Session::get('update'))
            <div class="alert alert-success">
                <strong>{{ $message }}</strong>
            </div>
          @endif
          

          @if (count($errors) > 0)
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
          @endif
<table class="table table-bordered table-dark">
  <thead>

    <tr>
      
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Usertype</th>
      <th  scope="col">Edit | Delete</th>
    
    </tr>
  </thead>
  <tbody>
     
 @foreach($user as $values) 
    <tr>
        <form>
      <input type="hidden" id='getid' value="<?php echo $values->id ?>" >
      <td><?php echo $values->name ?> </td>
      <td><?php echo $values->email ?></td>
      <td><?php echo  $values->userrole ?></td>     
      <td>
    <input type="button" data-toggle="modal" data-target="#exampleModal"
     class="the_id btn btn-primary" data-key="<?php echo $values->id ?>" id="edit" value="Edit">
      <input type="button" class="the_id2 btn btn-success" data-key="<?php echo $values->id ?>" id="delete" value="Delete"></td>
    </tr>
</form>
 @endforeach 
   
  </tbody>
</table>
</div>

@endsection
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>  


<script>
 
    $(document).ready(function () {  
        $('.the_id').click(function(){
        
     var id = $(this).attr('data-key');
     //alert(id)
    $.ajax({
           type:'GET',
           url:"{{ route('edit') }}",
          // url:'/edit',
           data:{id:id},
           success:function(data){
            $('#getid').val(data.id)
             $('#name').val(data.name)
             $('#exampleInputEmail1').val(data.email)
             $('#userrole').val(data.userrole)
              // alert(data.name);
              // alert(data.email);
           }
        }); 
   
   
})
$('.the_id2').click(function(){
        
        var id = $(this).attr('data-key');
       // alert(id)
       $.ajax({
              type:'GET',
              url:"{{ route('delete') }}",
             // url:'/edit',
              data:{id:id},
              success:function(data){
                
                  alert('Record Delted successfully');
                  location.reload(true);
              }
           }); 
      
      
   })

    })
      </script>
      <!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="/update" method="post">
      @csrf
      <input type="text" class="form-control" name="getid" id="getid"  >
      <div class="form-group">
      <label for="Name">Name</label>
      <input type="text" class="form-control" name="name" id="name"  placeholder="Enter Name"  required>
      
    </div>
    <div class="form-group">
      <label for="Name">Userrole</label>
      <input type="text" class="form-control" name="userrole" id="userrole"  placeholder="Enter userrole"  required>
      
    </div>

    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>            
    </div>

       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" id="update" class="btn btn-primary">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

      

