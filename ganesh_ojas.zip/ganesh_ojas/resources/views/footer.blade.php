<!-- 
<div class="panel-footer">Panel footer</div> -->
<div class="footer">
  <p>Copy right &copy; Ojas </p>
</div>
